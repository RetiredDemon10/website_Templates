<!-- footer styles -->

<style>.u-footer .u-sheet-1 {
  min-height: 83px;
}
.u-footer .u-image-1 {
  width: 184px;
  height: 66px;
  margin: 8px auto 0 0;
}
.u-footer .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-footer .u-social-icons-1 {
  height: 56px;
  min-height: 16px;
  width: 189px;
  min-width: 68px;
  margin: -67px 15px 19px auto;
}
.u-footer .u-icon-1 {
  color: rgb(59, 89, 152) !important;
  height: 100%;
}
.u-footer .u-icon-2 {
  color: rgb(85, 172, 238) !important;
  height: 100%;
}
.u-footer .u-icon-3 {
  color: rgb(197, 54, 164) !important;
  height: 100%;
}
@media (max-width: 1199px) {
  .u-footer .u-image-1 {
    width: 184px;
  }
  .u-footer .u-social-icons-1 {
    width: 189px;
  }
}</style>
